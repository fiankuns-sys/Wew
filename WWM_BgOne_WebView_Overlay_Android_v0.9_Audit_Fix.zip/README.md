# WWM · BgOne WebView Overlay v0.9 (audit hardening)

Aplikasi pendamping Android yang membuka **https://bgonegaming.win/wherewindmeets/** di dalam WebView melayang, ketika Android dan game mengizinkan. Tidak menyalin aset, tidak membaca memori game, tidak mengubah APK game, tidak memakai Accessibility atau tangkapan layar.

> **Status:** source code diperbaiki dan lolos audit offline; **belum dikompilasi penuh** dan **belum diuji bersama Where Winds Meet pada perangkat asli**. Tidak ada klaim 100% bebas bug.

## Fitur utama

- Gelembung **PETA**: ketuk untuk interaktif, tahan sekitar 0,56 detik untuk **Quick Peek** selama 9 detik.
- **Mode Interaktif**: pin dan galeri website dapat diketuk; geser panel, ubah ukuran, pilih opasitas, kunci posisi.
- **Mode Lihat**: WebView noninteraktif dan tombol **ATUR** terpisah. Sistem membatasi opasitas berdasarkan batas obscuring touch Android saat tersedia. **Tidak menjamin** sentuhan dapat diteruskan di semua game.
- Pencarian dengan tombol **Ketik/Main** untuk fokus keyboard. Minimize menutup keyboard.
- Memori posisi jendela untuk orientasi horizontal/vertikal.
- Status loading, watchdog jika pemuatan berkepanjangan, tombol reload, Home, Back, Forward, buka browser utama.
- Penanganan HTTP error, sertifikat SSL, dan renderer WebView yang berhenti.
- Halaman dan cookie dipertahankan selama proses WebView hidup; jika sistem membuang proses, hanya URL aman terakhir yang bisa dipulihkan, bukan otomatis zoom/filter.
- Notifikasi foreground-service dengan tombol Perkecil/Hentikan.

## Koreksi utama v0.9

1. Callback WebView lama tidak dapat lagi mengubah status sesi baru setelah renderer dihancurkan.
2. Watchdog 45 detik memberi diagnostik ketika halaman terlalu lama dimuat, dan dibatalkan pada selesai/error/destroy.
3. Aturan domain HTTPS dipindah ke `NavigationPolicy`, diuji terhadap host yang meniru domain, URL tidak valid, dan query mengandung token.
4. URL tersimpan menghapus query/fragment/credential dan menjaga path yang sudah percent-encoded (misalnya `%20`).
5. Alpha pass-through memakai `InputManager.getMaximumObscuringOpacityForTouch()` jika tersedia, dengan margin konservatif 0,05; tidak hanya angka tetap.
6. Kegagalan `startForeground` atau pembuatan gelembung membuat service berhenti; tidak terus mengulang dalam kondisi sebagian terpasang.
7. Orientasi ditangani ulang setelah konfigurasi layar berubah untuk mengurangi kasus ukuran lama.
8. Kegagalan menginisialisasi WebView menampilkan status error, sehingga header aplikasi tetap dapat digunakan untuk membuka browser utama.
9. Izin notifikasi diminta **sebelum** overlay aktif agar dialog izin tidak tertutup panel sendiri.
10. Website WebView tetap menonaktifkan file/content access dan HTTP cleartext; metadata Safe Browsing ditambahkan.

## Build di GitHub Actions

1. Ekstrak ZIP dan unggah **seluruh isi folder** ke root repositori GitHub: `app/`, `.github/`, `tests/`, `settings.gradle`, dan sebagainya.
2. Buka **Actions → Bangun APK Android → Run workflow**.
3. Workflow menjalankan pemeriksaan Java offline, Android Lint, lalu `assembleDebug`.
4. Jika build berhasil, unduh artifact `WWM-BgOne-Overlay-v0.9-debug` → `app-debug.apk`.
5. Pasang APK, berikan izin **Tampil di atas aplikasi lain**, lalu buka aplikasi dan jalankan overlay. Gunakan peta saat game mengizinkan overlay.

## Pengujian yang sudah dilakukan

```bash
python3 tests/check_source.py
```

- **35/35 cek offline** lulus; sebagian cek memvalidasi struktur, tidak berarti uji end-to-end.
- **24.129 asersi Java deterministik** lulus untuk domain URL, URL tersimpan, opasitas, dan 4.000 set geometri layar acak.
- Konfigurasi YAML workflow berhasil diparse.
- **Belum diuji:** kompilasi dengan Android SDK, Android Lint sesungguhnya, pemasangan APK, WebView BgOne pada layar game, baterai/suhu/RAM, kompatibilitas perangkat dan ROM. SDK/Gradle tidak tersedia dan koneksi unduhan Google tidak dapat dijangkau di lingkungan pembuatan ini.

Lihat `docs/AUDIT_V09.md` dan `docs/QA_ANDROID.md` untuk daftar kasus dan penanganan bug.

## Privasi dan batasan

Situs BgOne tetap menangani login, cookie, progress, gambar, dan data website. Beberapa fitur web (login federasi, file upload/download, popup, anti-bot) dapat memerlukan browser utama. Website berubah tanpa kendali proyek ini. Panel tidak bisa mengatasi kebijakan Android maupun game yang memblokir overlay. Tidak terafiliasi dengan BgOne maupun penerbit Where Winds Meet.
