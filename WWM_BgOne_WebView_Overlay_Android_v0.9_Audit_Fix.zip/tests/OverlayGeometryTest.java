package id.wwm.bgoneoverlay;

public final class OverlayGeometryTest {
    public static void main(String[] args) {
        OverlayGeometry.Bounds b = OverlayGeometry.interactive(1080, 500, -40, 900, 700, 400, 240, 190);
        assert b.x == 0 && b.y == 100 && b.width == 700 && b.height == 400;
        OverlayGeometry.Bounds p = OverlayGeometry.readOnly(1080, 500, -10, 0, 1000, 450, 240, 190, 80);
        assert p.x >= 80 && p.x + p.width <= 1080;
        assert p.y + p.height <= 500;
        OverlayGeometry.Bounds mobile = OverlayGeometry.readOnly(320, 700, 300, 400, 400, 900, 240, 190, 72);
        assert mobile.x >= 72 && mobile.x + mobile.width <= 320;
        assert mobile.y + mobile.height <= 700;
        assert OverlayGeometry.readOnlyAlpha(1f) <= .8f;
        assert OverlayGeometry.readOnlyAlpha(.6f) == .6f;
        System.out.println("PASS: geometry, reserved controller, safe alpha, portrait/landscape");
    }
}
