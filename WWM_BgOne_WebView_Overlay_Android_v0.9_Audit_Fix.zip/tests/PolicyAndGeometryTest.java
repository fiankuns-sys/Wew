package id.wwm.bgoneoverlay;

import java.util.Random;

public final class PolicyAndGeometryTest {
    private static int checks;
    static void okay(boolean condition, String what) {
        checks++;
        if (!condition) throw new AssertionError("FAILED: " + what);
    }
    public static void main(String[] args) {
        okay(NavigationPolicy.isBgOne("https", "bgonegaming.win"), "main domain");
        okay(NavigationPolicy.isBgOne("HTTPS", "Map.BGONEGAMING.WIN"), "case-insensitive subdomain");
        for (String host : new String[]{"bgonegaming.win.evil.com", "xbgonegaming.win",
                "other.gg", "bgonegaming.win.attacker.co", ""}) {
            okay(!NavigationPolicy.isBgOne("https", host), "host must not be allowlisted: " + host);
        }
        okay(!NavigationPolicy.isBgOne("http", "bgonegaming.win"), "http blocked");
        okay(!NavigationPolicy.isBgOne("file", "bgonegaming.win"), "file blocked");
        okay(!NavigationPolicy.isBgOne("javascript", "bgonegaming.win"), "javascript blocked");
        okay(!NavigationPolicy.isBgOne("https", null), "missing host blocked");
        String home = "https://bgonegaming.win/wherewindmeets/";
        okay(home.equals(NavigationPolicy.persistentUrl(
                "https://bgonegaming.win/wherewindmeets/?token=secret#x", home)), "strip tokens");
        okay(home.equals(NavigationPolicy.persistentUrl(
                "https://evil.example/?token=secret", home)), "reject offsite persisted URL");
        okay(home.equals(NavigationPolicy.persistentUrl(
                "https://login:secret@bgonegaming.win/wherewindmeets/", home)), "reject userinfo");
        okay(home.equals(NavigationPolicy.persistentUrl(null, home)), "null URL");
        okay(home.equals(NavigationPolicy.persistentUrl("%%broken%%", home)), "invalid URL");
        okay("https://bgonegaming.win/map/One%20Two".equals(
                NavigationPolicy.persistentUrl("https://bgonegaming.win/map/One%20Two?secret=x", home)),
                "keep encoded path intact");
        okay(NavigationPolicy.isExternalHttps("https", "example.org"), "external HTTPS");
        okay(!NavigationPolicy.isExternalHttps("intent", "example.org"), "no external intent protocol");

        float[] inputs = new float[]{0f, .1f, .25f, .5f, .8f, 1f};
        for (float selected : inputs) for (float limit : inputs) {
            float got = OverlayGeometry.readOnlyAlpha(selected, limit);
            okay(got >= 0f && got <= .75f, "opacity in range");
            okay(got <= selected + 1e-6f, "does not exceed selection");
            okay(got <= Math.max(0, limit - .05f) + 1e-6f, "honors device opacity");
        }
        okay(OverlayGeometry.readOnlyAlpha(Float.NaN, .8f)==0f, "NaN safely handled");
        okay(OverlayGeometry.readOnlyAlpha(.8f, Float.NaN)==0f, "device NaN safely handled");

        Random random = new Random(0x41af33);
        for (int i=0; i<4000; i++) {
            int sw = 160 + random.nextInt(3800);
            int sh = 160 + random.nextInt(2400);
            int x = random.nextInt(10000) - 3000;
            int y = random.nextInt(10000) - 3000;
            int w = random.nextInt(5000) + 1;
            int h = random.nextInt(4000) + 1;
            int minW = 160 + random.nextInt(200);
            int minH = 140 + random.nextInt(200);
            OverlayGeometry.Bounds a = OverlayGeometry.interactive(sw, sh, x, y, w, h, minW, minH);
            okay(a.x >= 0 && a.y >= 0, "interactive positive origins");
            okay(a.width >= 1 && a.height >= 1, "interactive positive sizes");
            okay(a.x + a.width <= sw && a.y + a.height <= sh, "interactive inside screen");
            int reserved = 48 + random.nextInt(110);
            OverlayGeometry.Bounds b = OverlayGeometry.readOnly(sw, sh, x, y, w, h, minW, minH, reserved);
            okay(b.x >= Math.min(sw/2, reserved), "read control reserved strip");
            okay(b.x + b.width <= sw && b.y + b.height <= sh, "passive inside screen");
            okay(b.width >= 1 && b.height >= 1, "passive nonzero size");
        }
        System.out.println("PASS: " + checks + " deterministic checks: URLs, opacity, geometry fuzz");
    }
}
