# Audit Overlay v0.6 → v0.7 — 11 November 2026

## Kebutuhan yang dipertahankan

- Peta **situs BgOne langsung**, bukan gambar palsu atau data lokal.
- Jendela melayang tampil di atas game jika diperbolehkan perangkat.
- Halaman tetap tersedia sesudah minimize ke tombol PETA selama service hidup.

## Temuan dan penanganan

| Komponen | Masalah v0.6 | Penanganan v0.7 | Status |
|---|---|---|---|
| Peta gagal dimuat | Hanya Toast | Status bar dengan retry dan HTTP/SSL/jaringan | Kode diperiksa |
| Renderer dihentikan | Risiko crash proses aplikasi | `onRenderProcessGone`, hancurkan instance dan buat baru | Kode diperiksa |
| Tab baru / popup | `setSupportMultipleWindows(false)` | Popup yang dipicu pengguna dialihkan ke browser utama | Kode diperiksa, perlu diuji |
| Panel | Hanya tiga ukuran tetap | Resize dengan seret sudut + tiga preset | Kode diperiksa, perlu diuji |
| Pengaturan | Hilang di sesi berikutnya | SharedPreferences posisi, ukuran, transparansi | Kode diperiksa |
| Berhenti | Tombol × saja | Tombol × serta aksi notifikasi | Kode diperiksa |
| Fokus keyboard | Bisa membingungkan | Tombol Ketik/Main dan bantuan di layar | Kode diperiksa, perlu uji perangkat |
| Unggah/unduh | Tak tertangani | Fallback eksplisit ke browser utama | Tidak sama persis dengan Chrome |
| HTTPS | Tidak jelas feedback | Sertifikat rusak ditolak + status | Kode diperiksa |
| Portrait/landscape | Dimensi preset saja | Batas panel menyesuaikan ukuran layar | Kode diperiksa, perlu uji rotasi |

## Uji perangkat yang belum dilakukan

1. Build dan instal APK di Android 13–16, termasuk Android 16 dengan pembatasan overlay OEM.
2. Cek izin overlay dan notifikasi, lalu buka game nyata.
3. Uji tombol PETA di atas game dalam landscape; tap game di area di luar overlay.
4. Buka peta utama dan empat pilihan wilayah, tap pin foto, cari, filter, zoom/pan, dan tandai progres di situs.
5. Uji minimize → buka lagi, pindah/resize, perubahan transparansi, rotasi, serta keluar/masuk game.
6. Uji login BgOne dengan akun percobaan, popup, cookie, galeri foto, lazy-loaded images.
7. Uji tanpa internet, sertifikat invalid (tanpa bypass), HTTP error, konsumsi RAM, dan perender dihentikan oleh sistem.
8. Uji tombol browser, keyboard, notif stop, serta perilaku bila sistem/game menolak overlay.

**Belum lulus uji di atas**. Jangan menyatakan aplikasi sempurna sampai semua skenario inti benar-benar teruji.

## Hal yang tidak mungkin dijanjikan

- Overlay tampil di semua game dan semua varian Android.
- Semua fitur website sama dengan browser lengkap; WebView berbeda dan situs berhak memblokirnya.
- Peta ikut posisi karakter otomatis; tidak ada akses lokasi internal game.
- Pin/foto bekerja offline; konten tetap dari BgOne dan memerlukan internet.
