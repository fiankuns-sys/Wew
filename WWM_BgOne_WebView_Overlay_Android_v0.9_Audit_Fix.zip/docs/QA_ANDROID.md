# QA DI ANDROID — WWM BgOne Overlay v0.9

Panduan untuk menguji APK secara aman melalui fitur Android resmi.

## Build

Unggah isi ZIP ke root repository GitHub sendiri. Buka Actions → Bangun APK Android → Run workflow. Periksa tes source, `lintDebug`, dan `assembleDebug`; unduh APK dari artifact hanya bila semuanya berhasil.

## Uji inti di perangkat

1. **Izin overlay:** pertama kali membuka aplikasi, berikan izin “Tampil di atas aplikasi lain”. Tutup izin lagi dan pastikan aplikasi tidak crash.
2. **Mulai/hentikan:** ketuk Mulai, pastikan gelembung PETA ada. Hentikan dari notifikasi dan dari aplikasi. Jalankan berulang 10 kali.
3. **Game:** buka WWM, amati apakah gelembung muncul. Jika tidak, gunakan browser utama; jangan mencoba menghindari kebijakan game.
4. **WebView:** ketuk gelembung, periksa peta asli, filter, pinch zoom, buka minimal 10 pin, tampilan foto, dan navigasi back/forward.
5. **Keyboard:** ketuk Ketik, cari lokasi, lalu Main. Ulangi dengan Minimize; game harus menerima input lagi.
6. **Mode Lihat:** ketuk ◉ dan coba kontrol game di area peta. Hasil mungkin berbeda antar-perangkat. Jika terhalang, pakai Quick Peek / minimize.
7. **Quick Peek:** tahan gelembung, pastikan peta hilang otomatis sekitar 9 detik; tombol TUTUP bekerja.
8. **Pengaturan:** geser, resize, kunci posisi, opasitas, ganti orientasi. Tutup aplikasi lalu jalankan ulang untuk melihat profil tersimpan.
9. **Gangguan:** putus jaringan sementara, ketuk reload setelah kembali; pindah ke aplikasi lain; uji proses dihentikan Android.
10. **Performa:** main 20–30 menit sambil mengamati kelancaran WWM, suhu, dan apakah overlay mendadak hilang.

## Cara mencatat laporan bug

Isi: versi Android dan WebView, jenis perangkat, langkah reproduksi, apa yang diharapkan, apa yang terjadi, serta tangkapan layar jika aman. Jangan unggah kata sandi, cookie, atau data pribadi.

Jika kamu menggunakan ADB dari komputer, log spesifik aplikasi dapat diperiksa dengan:

```bash
adb logcat -v time -s WWMOverlay AndroidRuntime chromium
```

Log dapat mengandung informasi pribadi; periksa dan hapus bagian sensitif sebelum dibagikan.

## Status

Daftar ini adalah **rencana pengujian**, bukan tes yang telah dijalankan di WWM.
