# AUDIT APLIKASI WWM BGONE WEBVIEW OVERLAY v0.9

Tanggal: 11 November 2026. Acuan: source code v0.8, dokumen Android resmi, pemeriksaan statis v0.9, tes Java properti.

## Kesimpulan

**Tidak mungkin menjamin aplikasi tanpa bug hanya dari pembacaan source.** v0.9 memperbaiki beberapa risiko nyata dan memperluas pengujian offline. Pengujian APK dengan Android SDK dan pengujian bersama game WWM tetap merupakan syarat penerimaan.

## Perubahan yang diterapkan

| ID | Masalah pada v0.8 | Perubahan v0.9 | Bukti tersedia |
|---|---|---|---|
| C-01 | Callback WebView usang setelah crash | Verifikasi identitas WebView dalam callback status/error | Pemeriksaan kode; tes perangkat belum |
| C-02 | Halaman menggantung tanpa umpan balik | Watchdog 45 detik, bersih saat selesai/error/destroy | Pemeriksaan kode |
| C-03 | Pembatasan alpha memakai asumsi Android 12 | Baca opacity limit perangkat dan sisakan headroom | Unit test dan source |
| C-04 | Start FGS gagal dapat meninggalkan startup parsial | `foregroundReady` menghentikan siklus startup gagal | Pemeriksaan kode |
| C-05 | Penggantian rotasi dapat memakai metrik layar lama | Reflow tertunda lewat UI queue | Pemeriksaan kode; tes perangkat belum |
| C-06 | Validasi domain tersebar & kurang diuji | `NavigationPolicy` terisolasi untuk pengujian | Unit test |
| C-07 | Pemulihan URL berisiko salah menyimpan token / path encode | Sanitasi URL dan pelestarian encoding pada path | Unit test |
| C-08 | WebView engine bisa gagal dibuat | Tangani error inisialisasi, tampilkan fallback browser | Pemeriksaan kode |
| C-09 | Dialog izin notifikasi diminta setelah overlay aktif | Minta izin notifikasi lebih dahulu | Pemeriksaan kode |
| C-10 | Safe Browsing hanya disetel dalam WebSettings | Tambah manifest metadata Safe Browsing | Pemeriksaan manifest |

## Matriks risiko tersisa

| Tingkat | Risiko tersisa | Mengapa belum selesai | Cara memverifikasi |
|---|---|---|---|
| P0 | Game memblokir `TYPE_APPLICATION_OVERLAY` | Kebijakan game atau ROM dapat menolak | Uji aplikasi + WWM bersamaan |
| P0 | Sentuhan pass-through ditolak oleh Android | Opasitas gabungan, jendela lain, kebijakan keamanan | Uji Mode Lihat di area kontrol game; gunakan Quick Peek jika gagal |
| P0 | APK gagal build | Tidak ada Android SDK/Gradle di lingkungan ini | Jalankan workflow, inspeksi log lint/build |
| P1 | Konsumsi RAM/GPU tinggi | Konten web JS/GPU bervariasi, game menekan memori | Uji 20–30 menit, proses hidup/mati |
| P1 | Keyboard/fokus pada ROM tertentu | Implementasi IME dan overlay berbeda antar-ROM | Ketik -> minimize -> kontrol game di berbagai ROM |
| P1 | Login BgOne atau progress tidak sinkron | Cookie, popup, anti-bot / third-party cookie | Tes login dan progres melalui browser & WebView |
| P1 | Pin dan galeri gagal pada WebView tertentu | Situs dapat butuh API web atau gesture kompleks | Ketuk 10 pin, pilih gambar, zoom dan cari |
| P1 | Rotasi, cutout, fullscreen | Android 15+ dan vendor dapat mengubah ukuran yang dapat dipakai | Uji landscape, portrait, gestural navigation, notch |
| P1 | Popup login / tautan khusus | Tautan popup HTTPS dibuka browser utama, bukan panel | Uji tombol login, galeri popup, unduh |
| P2 | Tombol kecil pada layar 6–7 inci | Sudut dan DPI yang berubah | Uji aksesibilitas sentuh manual |

## Keamanan & kebijakan

- Domain internal: HTTPS `bgonegaming.win` dan subdomain valid; domain jebakan seperti `bgonegaming.win.evil.com` ditolak.
- Akses `file://` / `content://` di WebView dinonaktifkan; cleartext traffic dinonaktifkan.
- Popup dibatasi gesture pengguna, lalu link HTTPS dibuka di browser utama.
- Tidak menambahkan JavaScript bridge, tidak mengambil data game, tidak memakai izin aksesibilitas, capture, atau root.
- `FOREGROUND_SERVICE_SPECIAL_USE` telah dideklarasikan, tetapi distribusi Google Play mungkin membutuhkan peninjauan deklarasi khusus.
- Mode Lihat bukan fitur bypass pembatasan keamanan game; tetap ada kemungkinan sentuhan di bawah overlay diblokir oleh sistem.

## Bukti pengujian 11-11-2026

- `python3 tests/check_source.py`: **35/35 pemeriksaan offline lulus**.
- `tests/PolicyAndGeometryTest.java`: **24.129 asersi Java**, termasuk 4.000 geometri acak, lulus.
- `tests/OverlayGeometryTest.java`: tes batas yang ditentukan sebelumnya, lulus.
- YAML workflow: valid sebagai YAML.
- Build Gradle: **BELUM** — SDK, Gradle, dan koneksi dependensi tidak tersedia.
- APK di WWM: **BELUM** — tidak ada perangkat Android yang dapat dikendalikan dari lingkungan kerja ini.

## Rujukan resmi

- Android 12 untrusted touch: https://developer.android.com/about/versions/12/behavior-changes-all
- Android 15 FGS background restrictions: https://developer.android.com/about/versions/15/behavior-changes-15
- Android WebView renderer recovery: https://developer.android.com/develop/ui/views/layout/webapps/handle-termination
- WebView security: https://developer.android.com/privacy-and-security/risks/webview-unsafe-file-inclusion
- Foreground service type: https://developer.android.com/develop/background-work/services/fgs/service-types

## Kriteria kelulusan rilis pertama

1. `lintDebug` dan `assembleDebug` berhasil di GitHub Actions.
2. Android dapat memasang dan menjalankan APK tanpa crash, FGS dapat dihentikan normal.
3. Overlay menampilkan BgOne di atas WWM **jika game mengizinkan**, dan fallback browser dapat digunakan bila tidak.
4. 10 pin dan galerinya merespons, keyboard pencarian bekerja.
5. Quick Peek menyembunyikan panel ~9 detik tanpa menjebak sentuhan game.
6. Posisi dan ukuran tersimpan setelah orientasi berganti.
7. Kegagalan jaringan dan penghentian renderer tidak menghentikan seluruh aplikasi.
8. Memori, suhu, dan kelancaran game masih dapat diterima pada uji panjang.
