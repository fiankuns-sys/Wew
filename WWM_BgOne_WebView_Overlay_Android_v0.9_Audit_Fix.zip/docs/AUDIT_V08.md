# Audit v0.8 — 11 November 2026

## Ruang lingkup yang benar-benar dikerjakan

Source v0.7 telah diperiksa dan dipisahkan menjadi:
1. `MapOverlayService` — jendela, transisi mode, geometri/UI, izin, lifecycle service.
2. `BrowserController` — WebView dan sesi situs, navigasi, error, crash renderer, popup, cookie.
3. `OverlayGeometry` — perhitungan batas panel dan jalur kontrol Mode Lihat. Bisa diuji tanpa Android SDK.

`tests/check_source.py` adalah pemeriksaan struktural plus compile-and-run tes Java murni. *Bukan* pengujian APK penuh. Perangkat Android dan game belum digunakan untuk tes.

## Matriks kebutuhan

| Item | Diterapkan di source | Validasi yang masih diperlukan |
|---|---|---|
| Mode Gelembung | Ya | Overlay muncul di atas WWM |
| Interaktif/klik pin situs | WebView native | Navigasi pin/galeri BgOne di perangkat |
| Mode Lihat noninteraktif | `FLAG_NOT_TOUCHABLE`, alpha ≤0,75 | Uji pass-through di WWM; tidak dijamin |
| Tombol ATUR terpisah | Ya, di kiri panel, tanpa tumpang tindih | Perangkat dengan cutout / berbagai DPI |
| Quick Peek 9 detik | Ya | Uji saat game landscape |
| Keyboard reset | Ya | Uji IME Android ROM spesifik |
| Kunci posisi, resize & preset | Ya | Uji sentuhan multitouch & rotasi |
| Profil portrait/landscape | Ya | Rotasi dan split-screen |
| Browser JS & DOM storage | Ya | Fungsionalitas situs; perubahan situs dapat memengaruhi |
| Popup | Dibatasi dan dibersihkan | Uji login BgOne dan link eksternal |
| Crash renderer | Destroy instance, rekreasi manual | Uji dengan sistem Android |
| Trim memory | Release WebView hanya saat tersembunyi dan tekanan memori | Uji WWM + Android System WebView |
| Restore setelah memori rendah | URL tanpa query + cookie | Zoom & filter tidak dijamin |
| Notifikasi FGS | Ya | Izin notifikasi Android 13–16 |
| Build APK | Workflow disiapkan | **Belum dijalankan** |
| Overlay di atas WWM | Struktur siap | **Belum diuji** |

## Keterbatasan keamanan sistem

- Window `TYPE_APPLICATION_OVERLAY` **bukan trusted overlay**; Android 12+ membatasi penerusan sentuhan. Opasitas maksimum standar untuk suatu panel noninteraktif adalah 0,8; aplikasi memilih 0,75 dan mencegah tombol kontrol bertumpang tindih panel. Ini **tidak mengalahkan** pengaturan game.
- Aplikasi tidak mengakses layar/game, tidak memakai AccessibilityService, tidak memodifikasi file game, dan tidak menginjeksi JavaScript ke situs BgOne.
- Foreground service `specialUse` memerlukan deklarasi dan berpotensi peninjauan tambahan jika APK didistribusikan lewat Google Play.
- Situs mungkin memiliki fitur login, anti-bot, peta WebGL, atau popup yang tidak bekerja di Android WebView. Gunakan browser utama sebagai fallback.

Referensi Android: https://developer.android.com/reference/android/view/WindowManager.LayoutParams (FLAG_NOT_TOUCHABLE dan batas opasitas), https://developer.android.com/reference/android/webkit/WebViewClient (onRenderProcessGone), https://developer.android.com/develop/background-work/services/fgs/changes.

## Urutan tes perangkat yang direkomendasikan

1. Bangun APK debug dan pastikan install tanpa crash.
2. Pastikan overlay muncul saat WWM aktif; jika game menolak, hentikan dan gunakan browser biasa.
3. Dalam mode Interaktif, sentuh pin, scroll/filter, buka foto, cari lokasi, dan back/forward.
4. Mode Lihat, coba kendali game; jika gagal, gunakan mode gelembung.
5. Quick Peek dari tahan gelembung dan tombol panel; ukur auto-hide sekitar 9 detik.
6. Buka keyboard pencarian, tutup panel, pastikan keyboard hilang.
7. Coba berbagai ukuran, posisi, landscape/portrait, kunci posisi, opacity.
8. Simulasikan jaringan terputus/aktif lagi dan cek tombol muat ulang.
9. Uji memori tinggi, renderer WebView terhenti, pindah aplikasi; cek fallback.
10. Uji 10–20 menit game dengan pemantauan FPS, suhu, RAM, dan stabilitas overlay.

Status seluruh tes perangkat: **BELUM DIJALANKAN**.
