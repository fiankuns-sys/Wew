package id.wwm.bgoneoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.hardware.input.InputManager;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** User initiated floating reference. No game-process access, automation or accessibility. */
public final class MapOverlayService extends Service implements BrowserController.Listener {
    public static final String ACTION_STOP = "id.wwm.bgoneoverlay.STOP";
    public static final String ACTION_HIDE = "id.wwm.bgoneoverlay.HIDE";
    public static final String ACTION_SHOW = "id.wwm.bgoneoverlay.SHOW";
    private static final int NOTICE_ID = 51;
    private static final String NOTICE_CHANNEL = "wwm_bgone_overlay_v09";
    private static final String PREFS = "overlay_ui_v08"; // Preserve user settings across upgrades.
    private static final float[] OPACITIES = {1f, .9f, .75f};
    private static final int PEEK_MILLIS = 9000;

    private enum Mode { BUBBLE, INTERACTIVE, VIEW, PEEK }

    private WindowManager wm;
    private SharedPreferences preferences;
    private BrowserController browser;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable peekTimeout = () -> { if (mode == Mode.PEEK) showBubble(); };
    private Mode mode = Mode.BUBBLE;

    private TextView bubble;
    private TextView readControl;
    private LinearLayout panel;
    private LinearLayout browserSlot;
    private TextView statusLabel;
    private TextView keyboardLabel;
    private TextView lockLabel;
    private WindowManager.LayoutParams bubbleLp, panelLp, controlLp;
    private boolean bubbleAdded, panelAdded, controlAdded;
    private boolean keyboardEnabled;
    private boolean foregroundReady;
    private boolean locked;
    private boolean landscape;
    private int sizeStep;
    private int alphaStep;
    private int px, py, pw, ph;
    private int bx, by;
    private boolean customSize;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        sizeStep = OverlayGeometry.clamp(preferences.getInt("size", 1), 0, 2);
        alphaStep = OverlayGeometry.clamp(preferences.getInt("alpha", 0), 0, 2);
        locked = preferences.getBoolean("locked", false);
        browser = new BrowserController(this, preferences, this);
        landscape = screenW() > screenH();
        loadProfile();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        // The service starts ONLY after a user presses Start in the visible
        // Activity. Avoid partially constructed windows on FGS startup failure.
        try {
            startForeground(NOTICE_ID, notification());
            foregroundReady = true;
            showBubble();
        } catch (RuntimeException error) {
            foregroundReady = false;
            android.util.Log.e("WWMOverlay", "Unable to start overlay service", error);
            stopSelf();
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!foregroundReady || !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_HIDE.equals(intent.getAction())) showBubble();
        else if (intent != null && ACTION_SHOW.equals(intent.getAction())) showInteractive();
        else if (!bubbleAdded && !panelAdded) showBubble();
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private Notification notification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(NOTICE_CHANNEL,
                "Peta BgOne melayang", NotificationManager.IMPORTANCE_LOW));
        PendingIntent launch = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), pendingFlags());
        PendingIntent hide = PendingIntent.getService(this, 1,
                new Intent(this, MapOverlayService.class).setAction(ACTION_HIDE), pendingFlags());
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, MapOverlayService.class).setAction(ACTION_STOP), pendingFlags());
        return new Notification.Builder(this, NOTICE_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_mapmode)
                .setContentTitle("WWM · BgOne Overlay aktif")
                .setContentText("Kontrol peta tersedia di layar atau notifikasi")
                .setContentIntent(launch)
                .addAction(android.R.drawable.ic_menu_view, "Perkecil", hide)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan", stop)
                .setOngoing(true)
                .build();
    }

    private int pendingFlags() { return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE; }
    private int dp(float amount) { return Math.round(amount * getResources().getDisplayMetrics().density); }
    private int toDp(int pixels) { return Math.round(pixels / getResources().getDisplayMetrics().density); }

    private Point displaySize() {
        Point point = new Point();
        // getSize excludes most system decorations; don't use full real-size for overlay dragging.
        wm.getDefaultDisplay().getSize(point);
        if (point.x <= 0 || point.y <= 0) {
            point.x = getResources().getDisplayMetrics().widthPixels;
            point.y = getResources().getDisplayMetrics().heightPixels;
        }
        return point;
    }
    private int screenW() { return displaySize().x; }
    private int screenH() { return displaySize().y; }
    private int minW() { return dp(240); }
    private int minH() { return dp(240); }
    private String prefix() { return landscape ? "land_" : "port_"; }

    private void loadProfile() {
        String pre = prefix();
        int width = screenW(), height = screenH();
        float[] widths = landscape ? new float[]{.4f, .58f, .82f} : new float[]{.81f, .92f, .98f};
        float[] heights = {.59f, .76f, .91f};
        int defaultW = Math.round(width * widths[sizeStep]);
        int defaultH = Math.round(height * heights[sizeStep]);
        customSize = preferences.getBoolean(pre + "custom", false);
        px = dp(preferences.getInt(pre + "px", 18));
        py = dp(preferences.getInt(pre + "py", 72));
        pw = customSize ? dp(preferences.getInt(pre + "pw", toDp(defaultW))) : defaultW;
        ph = customSize ? dp(preferences.getInt(pre + "ph", toDp(defaultH))) : defaultH;
        bx = dp(preferences.getInt(pre + "bx", 12));
        by = dp(preferences.getInt(pre + "by", 90));
        OverlayGeometry.Bounds b = OverlayGeometry.interactive(width, height,
                px, py, pw, ph, minW(), minH());
        px = b.x; py = b.y; pw = b.width; ph = b.height;
        bx = OverlayGeometry.clamp(bx, 0, Math.max(0, width - dp(68)));
        by = OverlayGeometry.clamp(by, 0, Math.max(0, height - dp(52)));
    }

    private void saveProfile() {
        String pre = prefix();
        preferences.edit()
                .putInt(pre + "px", toDp(px)).putInt(pre + "py", toDp(py))
                .putInt(pre + "pw", toDp(pw)).putInt(pre + "ph", toDp(ph))
                .putInt(pre + "bx", toDp(bx)).putInt(pre + "by", toDp(by))
                .putBoolean(pre + "custom", customSize)
                .putInt("size", sizeStep).putInt("alpha", alphaStep)
                .putBoolean("locked", locked).apply();
    }

    private WindowManager.LayoutParams windowParams(int w, int h, int x, int y, float alpha,
                                                    int otherFlags) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | otherFlags;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = x; p.y = y; p.alpha = alpha;
        p.setTitle("WWM BgOne reference overlay");
        return p;
    }

    private GradientDrawable background(int color, int round) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(round));
        drawable.setStroke(dp(1), 0xff51677d);
        return drawable;
    }

    private TextView button(String text, int size, String hint, Runnable click) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(0xfff0e4d1);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextSize(size);
        view.setGravity(Gravity.CENTER);
        view.setContentDescription(hint);
        view.setPadding(dp(3), dp(2), dp(3), dp(2));
        if (click != null) view.setOnClickListener(v -> click.run());
        return view;
    }

    private void removeBubble() {
        if (bubbleAdded) { try { wm.removeViewImmediate(bubble); } catch (RuntimeException ignored) { } }
        bubbleAdded = false;
    }
    private void removePanel() {
        if (panelAdded) { try { wm.removeViewImmediate(panel); } catch (RuntimeException ignored) { } }
        panelAdded = false;
    }
    private void removeControl() {
        if (controlAdded) { try { wm.removeViewImmediate(readControl); } catch (RuntimeException ignored) { } }
        controlAdded = false;
    }
    private void update(View view, WindowManager.LayoutParams lp, boolean attached) {
        if (view == null || lp == null || !attached) return;
        try { wm.updateViewLayout(view, lp); }
        catch (RuntimeException e) {
            android.util.Log.w("WWMOverlay", "Failed to update overlay layout", e);
            message("Jendela tidak dapat diperbarui.");
        }
    }

    private void cancelPeek() { handler.removeCallbacks(peekTimeout); }

    /** Single tap: interactive; long press: 9s noninteractive preview. */
    private View.OnTouchListener bubbleTouch() {
        return new View.OnTouchListener() {
            private int startX, startY;
            private float x0, y0;
            private boolean moved, held;
            private Runnable hold;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (bubbleLp == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleLp.x; startY = bubbleLp.y;
                        x0 = e.getRawX(); y0 = e.getRawY();
                        moved = false; held = false;
                        hold = () -> { if (!moved && bubbleAdded) { held = true; showPeek(); } };
                        handler.postDelayed(hold, 560);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - x0, dy = e.getRawY() - y0;
                        if (Math.abs(dx) > dp(7) || Math.abs(dy) > dp(7)) {
                            moved = true; handler.removeCallbacks(hold);
                        }
                        if (moved && bubbleAdded) {
                            bx = OverlayGeometry.clamp(startX + Math.round(dx), 0, screenW() - bubbleLp.width);
                            by = OverlayGeometry.clamp(startY + Math.round(dy), 0, screenH() - bubbleLp.height);
                            bubbleLp.x = bx; bubbleLp.y = by;
                            update(bubble, bubbleLp, bubbleAdded);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        handler.removeCallbacks(hold);
                        if (!moved && !held) showInteractive();
                        else saveProfile();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(hold);
                        saveProfile();
                        return true;
                    default: return false;
                }
            }
        };
    }

    private View.OnTouchListener dragPanel() {
        return new View.OnTouchListener() {
            private int x, y;
            private float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (locked || mode != Mode.INTERACTIVE || panelLp == null) return true;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x = px; y = py; downX = event.getRawX(); downY = event.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        OverlayGeometry.Bounds b = OverlayGeometry.interactive(screenW(), screenH(),
                                x + Math.round(event.getRawX()-downX), y + Math.round(event.getRawY()-downY),
                                pw, ph, minW(), minH());
                        px = b.x; py = b.y; panelLp.x = px; panelLp.y = py;
                        update(panel, panelLp, panelAdded);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        saveProfile(); return true;
                    default: return false;
                }
            }
        };
    }

    private View.OnTouchListener resizePanel() {
        return new View.OnTouchListener() {
            private int w, h;
            private float downX, downY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (locked || mode != Mode.INTERACTIVE || panelLp == null) return true;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        w = pw; h = ph; downX = e.getRawX(); downY = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        int maxW = Math.max(1, screenW()-px), maxH = Math.max(1, screenH()-py);
                        pw = OverlayGeometry.clamp(w+Math.round(e.getRawX()-downX), Math.min(maxW,minW()), maxW);
                        ph = OverlayGeometry.clamp(h+Math.round(e.getRawY()-downY), Math.min(maxH,minH()), maxH);
                        customSize = true;
                        panelLp.width = pw; panelLp.height = ph;
                        update(panel, panelLp, panelAdded); return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        saveProfile(); return true;
                    default: return false;
                }
            }
        };
    }

    private void makeBubble() {
        if (bubble != null) return;
        bubble = button("PETA", 12, "Ketuk untuk peta, tahan untuk Quick Peek", null);
        bubble.setBackground(background(0xff204963, 17));
        bubble.setElevation(dp(5));
        bubble.setOnTouchListener(bubbleTouch());
    }

    private void showBubble() {
        cancelPeek();
        exitKeyboard();
        if (mode == Mode.INTERACTIVE) saveProfile();
        removeControl();
        removePanel();
        browser.pause();
        mode = Mode.BUBBLE;
        makeBubble();
        if (!bubbleAdded) {
            bubbleLp = windowParams(dp(68), dp(52), bx, by, 1f, 0);
            try { wm.addView(bubble, bubbleLp); bubbleAdded = true; }
            catch (RuntimeException error) {
                foregroundReady = false;
                android.util.Log.w("WWMOverlay", "Unable to attach bubble window", error);
                message("Tampilan overlay dibatasi Android atau game.");
                stopSelf();
            }
        }
    }

    private void makePanel() {
        if (panel != null) return;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(background(0xff132333, 12));
        panel.setElevation(dp(5));

        LinearLayout header = new LinearLayout(this);
        header.setBackgroundColor(0xff20384d);
        header.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));
        TextView title = button("⋮⋮ BGONE · PETA", 12, "Seret untuk pindah (jika tidak dikunci)", null);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        title.setPadding(dp(8), 0, 0, 0);
        title.setOnTouchListener(dragPanel());
        header.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        header.addView(button("◉", 20, "Mode Lihat", this::showReadOnly), new LinearLayout.LayoutParams(dp(40), -1));
        header.addView(button("⏱", 17, "Quick Peek 9 detik", this::showPeek), new LinearLayout.LayoutParams(dp(40), -1));
        header.addView(button("—", 21, "Perkecil peta", this::showBubble), new LinearLayout.LayoutParams(dp(40), -1));
        header.addView(button("×", 22, "Hentikan overlay", this::stopSelf), new LinearLayout.LayoutParams(dp(40), -1));

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setFillViewport(false);
        scroller.setBackgroundColor(0xff1b2f42);
        panel.addView(scroller, new LinearLayout.LayoutParams(-1, dp(40)));
        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        scroller.addView(controls, new android.widget.FrameLayout.LayoutParams(-2, -1));
        addControl(controls, "‹", "Kembali", browser::back);
        addControl(controls, "›", "Maju", browser::forward);
        addControl(controls, "⌂", "Halaman utama BgOne", browser::home);
        addControl(controls, "↻", "Muat ulang", this::reload);
        addControl(controls, "▣", "Ganti ukuran", this::cycleSize);
        addControl(controls, "◐", "Atur transparansi", this::cycleOpacity);
        keyboardLabel = addControl(controls, "Ketik", "Atur keyboard", this::toggleKeyboard);
        lockLabel = addControl(controls, "Bebas", "Kunci / buka posisi", this::toggleLock);
        lockLabel.setText(locked ? "Kunci" : "Bebas");
        addControl(controls, "↗", "Buka website di browser utama", () -> openBrowser(Uri.parse(browser.currentUrl())));

        statusLabel = button("Memuat peta...", 11, "Status halaman, ketuk untuk muat ulang", this::reload);
        statusLabel.setBackgroundColor(0xff284258);
        panel.addView(statusLabel, new LinearLayout.LayoutParams(-1, dp(28)));
        browserSlot = new LinearLayout(this);
        browserSlot.setOrientation(LinearLayout.VERTICAL);
        panel.addView(browserSlot, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView note = button("Geser judul untuk pindah   •   ↘ ubah ukuran", 10,
                "Geser sudut untuk mengubah ukuran", null);
        LinearLayout footer = new LinearLayout(this);
        footer.setBackgroundColor(0xff213548);
        footer.addView(note, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView resize = button("↘", 22, "Ubah ukuran jendela", null);
        resize.setBackgroundColor(0xff36536a);
        resize.setOnTouchListener(resizePanel());
        footer.addView(resize, new LinearLayout.LayoutParams(dp(46), dp(30)));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(30)));
    }

    private TextView addControl(LinearLayout line, String label, String hint, Runnable click) {
        TextView view = button(label, label.length() > 2 ? 11 : 20, hint, click);
        line.addView(view, new LinearLayout.LayoutParams(label.length() > 2 ? dp(60) : dp(46), -1));
        return view;
    }

    private void attachBrowser() {
        if (browserSlot == null) return;
        final WebView web;
        try { web = browser.view(); }
        catch (RuntimeException error) {
            android.util.Log.e("WWMOverlay", "WebView is not available", error);
            status("Android System WebView bermasalah • gunakan ↗", true);
            return;
        }
        if (web.getParent() != browserSlot) {
            if (web.getParent() instanceof ViewGroup) ((ViewGroup) web.getParent()).removeView(web);
            browserSlot.removeAllViews();
            browserSlot.addView(web, new LinearLayout.LayoutParams(-1, -1));
        }
    }

    private void attachPanel() {
        makePanel();
        if (!panelAdded) {
            panelLp = windowParams(pw, ph, px, py, OPACITIES[alphaStep], 0);
            try { wm.addView(panel, panelLp); panelAdded = true; }
            catch (RuntimeException e) { message("Game atau Android menolak overlay peta."); showBubble(); return; }
        }
        attachBrowser();
        browser.resume();
    }

    private void showInteractive() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        cancelPeek();
        exitKeyboard();
        removeBubble();
        removeControl();
        if (mode == Mode.VIEW || mode == Mode.PEEK) {
            // The read-only view uses geometry that must never overwrite user preferences.
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        mode = Mode.INTERACTIVE;
        attachPanel();
        if (!panelAdded) return;
        OverlayGeometry.Bounds b = OverlayGeometry.interactive(screenW(), screenH(),
                px, py, pw, ph, minW(), minH());
        px = b.x; py = b.y; pw = b.width; ph = b.height;
        panelLp.x = px; panelLp.y = py; panelLp.width = pw; panelLp.height = ph;
        panelLp.alpha = OPACITIES[alphaStep];
        panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        update(panel, panelLp, panelAdded);
        saveProfile();
    }

    private void showReadOnly() { showPassive(false); }
    private void showPeek() { showPassive(true); }

    private void showPassive(boolean quick) {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        cancelPeek();
        exitKeyboard();
        if (mode == Mode.INTERACTIVE) saveProfile();
        removeBubble();
        mode = quick ? Mode.PEEK : Mode.VIEW;
        attachPanel();
        if (!panelAdded) return;
        int reserved = dp(74);
        OverlayGeometry.Bounds p = OverlayGeometry.readOnly(screenW(), screenH(),
                px, py, pw, ph, minW(), minH(), reserved);
        panelLp.x = p.x; panelLp.y = p.y; panelLp.width = p.width; panelLp.height = p.height;
        panelLp.alpha = safePassiveOpacity();
        panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        update(panel, panelLp, panelAdded);
        showReadControl(quick, p.y);
        if (quick) handler.postDelayed(peekTimeout, PEEK_MILLIS);
    }

    /** Honor the device's reported touch-occlusion limit instead of assuming 0.8. */
    private float safePassiveOpacity() {
        float deviceLimit = .8f;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                InputManager input = (InputManager) getSystemService(Context.INPUT_SERVICE);
                if (input != null) deviceLimit = input.getMaximumObscuringOpacityForTouch();
            } catch (RuntimeException ignored) {
                deviceLimit = .8f;
            }
        }
        return OverlayGeometry.readOnlyAlpha(OPACITIES[alphaStep], deviceLimit);
    }

    private void showReadControl(boolean quick, int y) {
        if (readControl == null) {
            readControl = button("ATUR", 11, "Ketuk untuk edit, tahan untuk perkecil", null);
            readControl.setBackground(background(0xff2b566f, 12));
            readControl.setOnClickListener(v -> {
                if (mode == Mode.PEEK) showBubble();
                else showInteractive();
            });
            readControl.setOnLongClickListener(v -> { showBubble(); return true; });
        }
        readControl.setText(quick ? "TUTUP" : "ATUR");
        if (controlAdded) removeControl();
        // A separate controller never overlaps the pass-through rectangle.
        controlLp = windowParams(dp(62), dp(52), dp(4),
                OverlayGeometry.clamp(y, 0, Math.max(0, screenH() - dp(52))), 1f, 0);
        try { wm.addView(readControl, controlLp); controlAdded = true; }
        catch (RuntimeException e) {
            message("Mode Lihat tidak didukung perangkat ini; peta diperkecil.");
            showBubble();
        }
    }

    private void reload() { attachBrowser(); browser.reload(); }

    private void toggleKeyboard() {
        if (mode != Mode.INTERACTIVE || !panelAdded || panelLp == null) return;
        keyboardEnabled = !keyboardEnabled;
        if (keyboardEnabled) {
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
            update(panel, panelLp, true);
            WebView current = browser.existingView();
            if (current != null) current.requestFocus();
            keyboardLabel.setText("Main");
            message("Ketuk kolom pencarian untuk mengetik.");
        } else exitKeyboard();
    }

    private void exitKeyboard() {
        if (browser == null) return;
        WebView current = browser.existingView();
        if (current != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(current.getWindowToken(), 0);
            current.clearFocus();
        }
        keyboardEnabled = false;
        if (panelLp != null) {
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;
            update(panel, panelLp, panelAdded);
        }
        if (keyboardLabel != null) keyboardLabel.setText("Ketik");
    }

    private void cycleSize() {
        if (mode != Mode.INTERACTIVE) return;
        sizeStep = (sizeStep+1) % 3;
        customSize = false;
        float[] widths = landscape ? new float[]{.40f, .58f, .82f} : new float[]{.81f, .92f, .98f};
        float[] heights = {.59f, .76f, .91f};
        pw = Math.round(screenW() * widths[sizeStep]);
        ph = Math.round(screenH() * heights[sizeStep]);
        OverlayGeometry.Bounds bounds = OverlayGeometry.interactive(screenW(), screenH(),
                px, py, pw, ph, minW(), minH());
        px = bounds.x; py = bounds.y; pw = bounds.width; ph = bounds.height;
        if (panelLp != null) {
            panelLp.width = pw; panelLp.height = ph; panelLp.x = px; panelLp.y = py;
            update(panel, panelLp, panelAdded);
        }
        saveProfile();
    }

    private void cycleOpacity() {
        alphaStep = (alphaStep + 1) % OPACITIES.length;
        if (panelLp != null && panelAdded && mode == Mode.INTERACTIVE) {
            panelLp.alpha = OPACITIES[alphaStep];
            update(panel, panelLp, true);
        }
        saveProfile();
        message("Opasitas peta: " + Math.round(OPACITIES[alphaStep]*100) + "%");
    }

    private void toggleLock() {
        locked = !locked;
        if (lockLabel != null) lockLabel.setText(locked ? "Kunci" : "Bebas");
        saveProfile();
    }

    @Override public void status(String label, boolean error) {
        if (statusLabel != null) {
            statusLabel.setText(label);
            statusLabel.setBackgroundColor(error ? 0xff753e38 : 0xff284258);
        }
    }

    @Override public void message(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override public void openBrowser(Uri link) {
        if (link == null || !"https".equalsIgnoreCase(link.getScheme())) {
            message("Hanya tautan HTTPS yang diizinkan."); return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, link);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (RuntimeException error) {
            message("Tidak dapat membuka browser utama.");
        }
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (mode == Mode.BUBBLE && level >= TRIM_MEMORY_RUNNING_LOW && level != TRIM_MEMORY_UI_HIDDEN) {
            browser.discardHidden();
        }
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        boolean nextLandscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (config.orientation != Configuration.ORIENTATION_PORTRAIT &&
                config.orientation != Configuration.ORIENTATION_LANDSCAPE) {
            nextLandscape = screenW() > screenH();
        }
        if (nextLandscape != landscape) {
            saveProfile(); // Save old orientation before switching keys.
            landscape = nextLandscape;
        }
        // Layout metrics may update after onConfigurationChanged. Re-evaluate on the UI queue.
        handler.post(() -> {
            if (wm == null) return;
            loadProfile();
            reflowCurrentWindow();
        });
    }

    private void reflowCurrentWindow() {
        if (mode == Mode.INTERACTIVE && panelAdded && panelLp != null) {
            panelLp.x=px; panelLp.y=py; panelLp.width=pw; panelLp.height=ph;
            update(panel, panelLp, true);
        } else if ((mode == Mode.VIEW || mode == Mode.PEEK) && panelAdded && panelLp != null) {
            OverlayGeometry.Bounds p = OverlayGeometry.readOnly(screenW(), screenH(),
                    px, py, pw, ph, minW(), minH(), dp(74));
            panelLp.x=p.x; panelLp.y=p.y; panelLp.width=p.width; panelLp.height=p.height;
            panelLp.alpha=safePassiveOpacity();
            update(panel,panelLp,true);
            if (controlLp != null) {
                controlLp.y = OverlayGeometry.clamp(p.y, 0, Math.max(0, screenH()-dp(52)));
                update(readControl,controlLp,controlAdded);
            }
        } else if (mode == Mode.BUBBLE && bubbleLp != null) {
            bubbleLp.x=bx; bubbleLp.y=by; update(bubble,bubbleLp,bubbleAdded);
        }
    }

    @Override public void onDestroy() {
        cancelPeek();
        exitKeyboard();
        saveProfile();
        removeControl();
        removePanel();
        removeBubble();
        browser.release();
        panel = null; browserSlot = null; statusLabel = null;
        handler.removeCallbacksAndMessages(null);
        wm = null;
        super.onDestroy();
    }
}
