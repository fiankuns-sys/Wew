package id.wwm.bgoneoverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private static final String MAP_URL = "https://bgonegaming.win/wherewindmeets/";
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(13, 21, 31));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(30), dp(22), dp(34));
        scroll.addView(body);
        addText(body, "WWM · BGONE OVERLAY", 24, 0xffedd4a6, true, 4);
        addText(body, "Peta asli BgOne sebagai jendela WebView melayang di atas Where Winds Meet.",
            15, 0xffc6d3dc, false, 10);
        addText(body, "VERSI 0.9 · TANPA ROOT · INTERNET DIPERLUKAN", 12,
            0xff94caba, true, 6);
        status = addText(body, "Memeriksa izin...", 14, 0xffb5dbc3, true, 16);

        addButton(body, "1  Berikan izin tampil di atas aplikasi lain", () -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            } catch (RuntimeException e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        addButton(body, "2  Jalankan peta melayang", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dahulu.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                      != PackageManager.PERMISSION_GRANTED &&
                    !getPreferences(MODE_PRIVATE).getBoolean("notif_requested", false)) {
                // Ask before adding an overlay, so a permission prompt is never
                // hidden under our own floating window.
                getPreferences(MODE_PRIVATE).edit().putBoolean("notif_requested", true).apply();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 200);
                return;
            }
            startMapService();
        });
        addButton(body, "Hentikan peta melayang", () ->
            stopService(new Intent(this, MapOverlayService.class)));
        addButton(body, "Buka website BgOne di browser utama", () -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(MAP_URL))); }
            catch (RuntimeException e) {
                Toast.makeText(this, "Browser belum tersedia.", Toast.LENGTH_SHORT).show();
            }
        });

        String webview = "Android System WebView: belum terdeteksi";
        try {
            android.content.pm.PackageInfo engine = WebView.getCurrentWebViewPackage();
            if (engine != null) webview = "Mesin WebView: " + engine.packageName +
                    " (" + engine.versionName + ")";
        } catch (RuntimeException ignored) { }
        addText(body, webview, 12, 0xffaabdcf, false, 20);
        addText(body,
            "PANDUAN PENGGUNAAN\n\n" +
            "1. Aktifkan izin overlay lalu jalankan peta dari tombol di atas.\n" +
            "2. Buka Where Winds Meet. Ketuk PETA untuk membuka peta interaktif.\n" +
            "3. Tahan tombol PETA selama setengah detik untuk Quick Peek 9 detik.\n" +
            "4. Dalam panel, tekan ◉ untuk Mode Lihat. Panel menjadi noninteraktif; " +
            "gunakan tombol ATUR terpisah untuk kembali mengedit.\n" +
            "5. Mode Lihat memakai opasitas maksimal 75%. Android/game masih dapat " +
            "membatasi sentuhan; untuk jaminan area bebas, perkecil sepenuhnya.\n" +
            "6. Tombol ⏱ mengaktifkan Quick Peek; panel otomatis menjadi gelembung " +
            "setelah sembilan detik. Tombol TUTUP dapat mempercepatnya.\n" +
            "7. Geser judul untuk memindahkan, seret ↘ untuk mengubah ukuran; " +
            "tombol Kunci menonaktifkan pemindahan tanpa sengaja.\n" +
            "8. Untuk pencarian, ketuk Ketik lalu kolom pencarian BgOne. " +
            "Tekan Main atau perkecil panel untuk menutup keyboard.\n" +
            "9. Tombol ↗ membuka halaman di browser utama jika login, " +
            "unggah, unduh atau popup tidak bekerja.\n\n" +
            "PERFORMA DAN PEMULIHAN\n\n" +
            "• Saat diperkecil, WebView dijeda. Jika memori menipis, " +
            "WebView bisa dilepas dan dibuka ulang ke URL terakhir.\n" +
            "• Jika WebView crash, ketuk status merah untuk memulihkan.\n" +
            "• Posisi/ukuran panel disimpan terpisah untuk layar portrait dan landscape.\n" +
            "• Ini adalah aplikasi pendamping tidak resmi; tidak memodifikasi game, " +
            "tidak mengakses posisi karakter atau melakukan otomatisasi.\n" +
            "• Jika game menyembunyikan overlay, aplikasi tidak berusaha melewati " +
            "pembatasan tersebut. Peta tetap bisa dibuka di browser utama.\n\n" +
            "PRIVASI\n\n" +
            "Website BgOne menangani data, foto, login, dan cookie. Aplikasi ini " +
            "tidak mengunduh aset ke dalam APK dan tidak terafiliasi dengan BgOne.",
            14, 0xffbfd0dd, false, 18);
        setContentView(scroll);
    }

    private void startMapService() {
        try {
            // Started by visible Activity after an explicit user action.
            startForegroundService(new Intent(this, MapOverlayService.class));
            Toast.makeText(this, "Overlay diminta. Buka game dan periksa tombol PETA.",
                    Toast.LENGTH_LONG).show();
        } catch (RuntimeException ex) {
            Toast.makeText(this, "Gagal memulai layanan: " + ex.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                    int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 200) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notifikasi ditolak; tombol Hentikan masih ada di aplikasi.",
                        Toast.LENGTH_LONG).show();
            }
            if (Settings.canDrawOverlays(this)) startMapService();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText(Settings.canDrawOverlays(this)
            ? "✓ Izin overlay aktif" : "! Izin overlay belum diberikan");
    }

    private TextView addText(LinearLayout parent, String body, int size, int color,
                             boolean bold, int marginTop) {
        TextView text = new TextView(this);
        text.setText(body);
        text.setTextColor(color);
        text.setTextSize(size);
        text.setLineSpacing(dp(2), 1.08f);
        text.setGravity(Gravity.START);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(marginTop);
        parent.addView(text, lp);
        return text;
    }

    private void addButton(LinearLayout parent, String caption, Runnable action) {
        Button button = new Button(this);
        button.setText(caption);
        button.setTextAllCaps(false);
        button.setTextColor(0xfff5ebde);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xff25364a);
        bg.setStroke(dp(1), 0xff64768a);
        bg.setCornerRadius(dp(13));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(55));
        lp.topMargin = dp(12);
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
    }

    private int dp(float x) {
        return Math.round(x * getResources().getDisplayMetrics().density);
    }
}
