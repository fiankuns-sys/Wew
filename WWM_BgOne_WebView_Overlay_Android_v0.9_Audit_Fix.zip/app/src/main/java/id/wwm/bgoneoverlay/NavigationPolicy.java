package id.wwm.bgoneoverlay;

import java.net.URI;
import java.util.Locale;

/** Strict host/scheme policy without Android dependencies, so it can be unit-tested. */
final class NavigationPolicy {
    private NavigationPolicy() { }
    static boolean isBgOne(String scheme, String host) {
        if (scheme == null || host == null || !"https".equalsIgnoreCase(scheme)) return false;
        String name = host.toLowerCase(Locale.US);
        return name.equals("bgonegaming.win") || name.endsWith(".bgonegaming.win");
    }
    static boolean isExternalHttps(String scheme, String host) {
        return "https".equalsIgnoreCase(scheme) && host != null && !host.isEmpty();
    }
    static String persistentUrl(String raw, String fallback) {
        if (raw == null) return fallback;
        try {
            URI parsed = URI.create(raw);
            if (!isBgOne(parsed.getScheme(), parsed.getHost())) return fallback;
            String authority = parsed.getRawAuthority();
            String path = parsed.getRawPath();
            // Avoid saving query, fragment or userinfo-bearing URLs.
            if (parsed.getUserInfo() != null || authority == null) return fallback;
            // Preserve already percent-encoded path segments; the multi-component
            // URI constructor would escape '%' a second time (e.g. %20 -> %2520).
            return "https://" + authority + (path == null || path.isEmpty() ? "/" : path);
        } catch (Exception ignored) {
            return fallback;
        }
    }
}
