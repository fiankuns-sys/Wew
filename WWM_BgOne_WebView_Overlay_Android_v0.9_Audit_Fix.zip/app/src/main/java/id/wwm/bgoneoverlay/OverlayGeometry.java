package id.wwm.bgoneoverlay;

/** Pure integer geometry for overlay positions; no Android framework dependency. */
final class OverlayGeometry {
    private OverlayGeometry() { }
    static final float MAX_SAFE_READ_ONLY_ALPHA = 0.75f; // Strictly below Android 12's 0.8 maximum.

    static final class Bounds {
        final int x, y, width, height;
        Bounds(int x, int y, int width, int height) {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
    }

    static int clamp(int n, int lower, int upper) {
        return Math.max(lower, Math.min(n, Math.max(lower, upper)));
    }

    static Bounds interactive(int screenW, int screenH, int x, int y, int width, int height,
                              int minW, int minH) {
        int w = clamp(width, Math.min(screenW, minW), screenW);
        int h = clamp(height, Math.min(screenH, minH), screenH);
        return new Bounds(clamp(x, 0, screenW - w), clamp(y, 0, screenH - h), w, h);
    }

    /** Reserve a completely separate left strip for the button that restores interactivity. */
    static Bounds readOnly(int screenW, int screenH, int x, int y, int width, int height,
                           int minW, int minH, int reservedLeft) {
        int left = Math.min(screenW / 2, Math.max(0, reservedLeft));
        int available = Math.max(1, screenW - left);
        int w = clamp(width, Math.min(available, minW), available);
        int h = clamp(height, Math.min(screenH, minH), screenH);
        int px = clamp(x, left, screenW - w);
        int py = clamp(y, 0, screenH - h);
        return new Bounds(px, py, w, h);
    }

    /** Conservative touch-occlusion limit, allowing for stricter device policies. */
    static float readOnlyAlpha(float selected, float deviceLimit) {
        if (Float.isNaN(selected) || Float.isNaN(deviceLimit)) return 0f;
        // The maximum is a per-UID combined opacity; this application keeps its
        // interactive controller outside the passive panel to avoid overlap.
        float headroom = Math.max(0f, Math.min(1f, deviceLimit) - .05f);
        return Math.min(Math.min(MAX_SAFE_READ_ONLY_ALPHA, headroom),
                Math.max(0f, Math.min(1f, selected)));
    }
    static float readOnlyAlpha(float selected) { return readOnlyAlpha(selected, .8f); }

    /** Transitions are explicit to prevent a passive panel accidentally retaining focus. */
    enum Mode { BUBBLE, INTERACTIVE, VIEW, PEEK }
    static boolean isPassive(Mode mode) { return mode == Mode.VIEW || mode == Mode.PEEK; }
    static boolean panelVisible(Mode mode) { return mode != Mode.BUBBLE; }
    static boolean needsTouch(Mode mode) { return mode == Mode.INTERACTIVE; }

}
