package id.wwm.bgoneoverlay;

import java.util.ArrayDeque;

/**
 * Pure Java renderer-failure circuit breaker.
 * Times must be monotonic milliseconds (SystemClock.elapsedRealtime on Android).
 * Keeps repeated renderer failures from automatically rebuilding a crash-looping page.
 */
final class RecoveryCircuitBreaker {
    private final int limit;
    private final long intervalMs;
    private final ArrayDeque<Long> failures = new ArrayDeque<>();
    private boolean blocked;

    RecoveryCircuitBreaker(int limit, long intervalMs) {
        if (limit < 1 || intervalMs < 1) throw new IllegalArgumentException("Invalid recovery policy");
        this.limit = limit;
        this.intervalMs = intervalMs;
    }

    boolean recordFailure(long nowMs) {
        // elapsedRealtime normally never decreases; guard tests/device edge cases.
        if (!failures.isEmpty() && nowMs < failures.peekLast()) failures.clear();
        while (!failures.isEmpty() && nowMs - failures.peekFirst() >= intervalMs) failures.removeFirst();
        failures.addLast(nowMs);
        if (failures.size() >= limit) blocked = true;
        return blocked;
    }

    boolean isBlocked() { return blocked; }

    void reset() {
        failures.clear();
        blocked = false;
    }
}
