package id.wwm.bgoneoverlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;

/** WebView lifecycle is independent of the window(s) that display it. */
final class BrowserController {
    interface Listener {
        void status(String text, boolean error);
        void message(String text);
        void openBrowser(Uri link);
    }

    static final String HOME_URL = "https://bgonegaming.win/wherewindmeets/";
    private final Context context;
    private final SharedPreferences preferences;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<WebView> popups = new ArrayList<>();
    private WebView browser;
    // Block automatic retries after repeated renderer crashes in a short window.
    private final RecoveryCircuitBreaker rendererGate = new RecoveryCircuitBreaker(3, 60_000L);
    private boolean paused = true;
    private boolean pageFailure;
    private String lastUrl;
    private int loadSequence = 0;
    private Runnable loadingWatchdog;

    BrowserController(Context context, SharedPreferences preferences, Listener listener) {
        this.context = context;
        this.preferences = preferences;
        this.listener = listener;
        String stored = preferences.getString("last_bgone_url", HOME_URL);
        lastUrl = NavigationPolicy.persistentUrl(stored, HOME_URL);
    }

    WebView existingView() { return browser; }

    WebView view() {
        if (rendererGate.isBlocked())
            throw new IllegalStateException("Renderer recovery paused; explicit retry required");
        if (browser == null) buildBrowser();
        return browser;
    }

    String currentUrl() {
        if (browser != null && browser.getUrl() != null && isBgOne(Uri.parse(browser.getUrl())))
            return browser.getUrl();
        return lastUrl;
    }

    void reload() {
        // This is a user-initiated retry. Automatic state transitions never reset the gate.
        if (rendererGate.isBlocked()) rendererGate.reset();
        boolean wasMissing = browser == null;
        WebView view = view(); // Creating a new instance already starts loadUrl(lastUrl).
        if (!wasMissing) {
            if (view.getUrl() == null) view.loadUrl(lastUrl);
            else view.reload();
        }
        listener.status("Menghubungkan ke BgOne...", false);
    }

    void home() {
        if (rendererGate.isBlocked()) rendererGate.reset();
        view().loadUrl(HOME_URL);
    }
    boolean canBack() { return browser != null && browser.canGoBack(); }
    boolean canForward() { return browser != null && browser.canGoForward(); }
    void back() { if (canBack()) browser.goBack(); }
    void forward() { if (canForward()) browser.goForward(); }

    void resume() {
        paused = false;
        if (browser != null) {
            browser.onResume();
            browser.resumeTimers();
        }
    }

    void pause() {
        paused = true;
        if (browser != null) {
            browser.onPause();
            browser.pauseTimers();
        }
        if (browser != null) CookieManager.getInstance().flush();
    }

    /** Discard only while hidden and memory-constrained. URL/cookies are preserved, JS state isn't. */
    void discardHidden() {
        if (paused) {
            destroyBrowser();
            listener.status("Memori dibebaskan; peta akan dimuat ulang.", false);
        }
    }

    void release() {
        paused = true;
        boolean wasActive = browser != null || !popups.isEmpty();
        destroyBrowser();
        for (WebView popup : new ArrayList<>(popups)) destroyPopup(popup);
        if (wasActive) CookieManager.getInstance().flush();
    }

    private boolean isBgOne(Uri uri) {
        if (uri == null || uri.getHost() == null || uri.getScheme() == null) return false;
        return NavigationPolicy.isBgOne(uri.getScheme(), uri.getHost());
    }

    private void remember(String url) {
        if (url != null && isBgOne(Uri.parse(url))) {
            // Don't persist query parameters, fragments or URL credentials.
            lastUrl = NavigationPolicy.persistentUrl(url, HOME_URL);
            preferences.edit().putString("last_bgone_url", lastUrl).apply();
        }
    }

    private void buildBrowser() {
        WebView web = new WebView(context);
        browser = web;
        web.setBackgroundColor(0xff0c1725);
        web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setGeolocationEnabled(false);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap favicon) {
                if (browser != v) return; // Ignore callbacks from disposed WebViews.
                pageFailure = false;
                remember(url);
                int id = ++loadSequence;
                cancelWatchdog();
                loadingWatchdog = () -> {
                    if (browser == v && loadSequence == id && !pageFailure) {
                        listener.status("Memuat terlalu lama • cek koneksi / ketuk ulang", true);
                    }
                };
                main.postDelayed(loadingWatchdog, 45000);
                listener.status("Memuat peta dan gambar...", false);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (browser != v) return;
                cancelWatchdog();
                remember(url);
                if (!pageFailure) listener.status("HTML dimuat • pastikan pin dan foto tampil", false);
                CookieManager.getInstance().flush();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                Uri target = req.getUrl();
                if (isBgOne(target)) return false;
                if (req.hasGesture() && target != null && "https".equalsIgnoreCase(target.getScheme()))
                    listener.openBrowser(target);
                else listener.message("Tautan luar diblokir. Gunakan browser utama jika diperlukan.");
                return true;
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (browser == v && req.isForMainFrame()) {
                    cancelWatchdog(); pageFailure = true;
                    listener.status("Gagal memuat • ketuk status untuk coba lagi", true);
                }
            }
            @Override public void onReceivedHttpError(WebView v, WebResourceRequest req, WebResourceResponse res) {
                if (browser == v && req.isForMainFrame() && res.getStatusCode() >= 400) {
                    cancelWatchdog(); pageFailure = true;
                    listener.status("HTTP " + res.getStatusCode() + " • ketuk untuk ulang", true);
                }
            }
            @Override public void onReceivedSslError(WebView v, SslErrorHandler handler, SslError err) {
                handler.cancel();
                if (browser == v) {
                    cancelWatchdog(); pageFailure = true;
                    listener.status("Sertifikat tidak valid • koneksi ditolak", true);
                }
            }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail details) {
                if (browser == v) {
                    cancelWatchdog();
                    ++loadSequence;
                    pageFailure = true;
                    browser = null;
                    boolean blocked = rendererGate.recordFailure(SystemClock.elapsedRealtime());
                    if (blocked) listener.status("WebView berhenti berulang • ketuk untuk mencoba manual atau gunakan ↗", true);
                    else listener.status("WebView berhenti • ketuk status untuk pulihkan", true);
                }
                // The dead instance must never be reused, per Android WebView contract.
                if (v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
                v.destroy();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView source, boolean isDialog,
                                                    boolean isUserGesture, Message result) {
                if (source != browser || !isUserGesture ||
                        !(result.obj instanceof WebView.WebViewTransport)) return false;
                WebView popup = new WebView(context);
                popups.add(popup);
                popup.getSettings().setJavaScriptEnabled(true);
                popup.getSettings().setDomStorageEnabled(false);
                popup.setWebViewClient(new WebViewClient() {
                    private boolean opened;
                    private void resolve(WebView view, String url) {
                        if (!opened && url != null && url.startsWith("https://")) {
                            opened = true;
                            listener.openBrowser(Uri.parse(url));
                        }
                        main.post(() -> destroyPopup(view));
                    }
                    @Override public void onPageStarted(WebView v, String url, Bitmap favicon) {
                        if (!"about:blank".equals(url)) resolve(v, url);
                    }
                    @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        resolve(v, r.getUrl().toString());
                        return true;
                    }
                    @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                        if (popups.remove(v)) {
                            if (v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
                            v.destroy(); // Renderer is dead; do not call stopLoading on it.
                        }
                        return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) result.obj;
                transport.setWebView(popup);
                result.sendToTarget();
                main.postDelayed(() -> destroyPopup(popup), 8000);
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, android.webkit.ValueCallback<Uri[]> callback,
                                                        FileChooserParams params) {
                callback.onReceiveValue(null);
                if (v == browser) listener.message("Unggah berkas melalui browser utama (↗).");
                return true;
            }
            @Override public void onProgressChanged(WebView v, int progress) {
                if (v == browser && progress < 100 && !pageFailure)
                    listener.status("Memuat BgOne " + progress + "%", false);
            }
        });
        web.setDownloadListener((url, ua, disposition, mime, len) -> {
            if (web != browser) return;
            if (url != null && url.startsWith("https://")) listener.openBrowser(Uri.parse(url));
            else listener.message("Unduh melalui browser utama.");
        });
        web.loadUrl(lastUrl);
        if (paused) {
            web.onPause();
            web.pauseTimers();
        }
    }

    private void cancelWatchdog() {
        if (loadingWatchdog != null) main.removeCallbacks(loadingWatchdog);
        loadingWatchdog = null;
    }

    private void destroyPopup(WebView view) {
        if (!popups.remove(view)) return;
        if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view);
        view.stopLoading();
        view.destroy();
    }

    private void destroyBrowser() {
        // Any temporary popup belongs to this session and must be disposed too.
        for (WebView popup : new ArrayList<>(popups)) destroyPopup(popup);
        WebView old = browser;
        if (old == null) return;
        cancelWatchdog();
        ++loadSequence;
        remember(old.getUrl());
        browser = null;
        if (old.getParent() instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);
        old.stopLoading();
        old.destroy();
    }
}
