package id.wwm.bgoneoverlay;

import java.util.ArrayDeque;
import java.util.Random;

/** Property and boundary tests of the exact recovery policy used in BrowserController. */
public final class RecoveryCircuitBreakerTest {
    private static long checked;
    private static void verify(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        checked++;
    }

    public static void main(String[] args) {
        RecoveryCircuitBreaker cb = new RecoveryCircuitBreaker(3, 60_000L);
        verify(!cb.isBlocked(), "starts unblocked");
        verify(!cb.recordFailure(1_000), "first event");
        verify(!cb.recordFailure(2_000), "second event");
        verify(cb.recordFailure(2_100), "third event blocks");
        verify(cb.isBlocked(), "latched block");
        cb.reset();
        verify(!cb.isBlocked(), "reset clears block");
        verify(!cb.recordFailure(0), "window first");
        verify(!cb.recordFailure(60_000), "expiration inclusive");
        verify(!cb.recordFailure(120_000), "events exactly a minute apart");
        verify(!cb.recordFailure(120_001), "second event after expired window");
        verify(cb.recordFailure(120_002), "third event in new window");
        cb.reset();
        verify(!cb.recordFailure(30_000), "rollback first");
        verify(!cb.recordFailure(10), "rollback clears series");
        verify(!cb.isBlocked(), "rollback must not block early");
        // Model-based randomized trials with independent counter logic.
        Random random = new Random(10052026L);
        for (int trial = 0; trial < 100; trial++) {
            cb.reset();
            ArrayDeque<Long> reference = new ArrayDeque<>();
            boolean expectedBlock = false;
            long now = 0;
            for (int i = 0; i < 200; i++) {
                if (random.nextInt(40) == 0) { // occasional monotonic reset
                    cb.reset();
                    reference.clear();
                    expectedBlock = false;
                    verify(!cb.isBlocked(), "reset at " + trial + ":" + i);
                }
                now += 1 + random.nextInt(50_000);
                while (!reference.isEmpty() && now - reference.peekFirst() >= 60_000)
                    reference.removeFirst();
                reference.addLast(now);
                if (reference.size() >= 3) expectedBlock = true;
                verify(cb.recordFailure(now) == expectedBlock,
                        "record result mismatch " + trial + ":" + i);
                verify(cb.isBlocked() == expectedBlock,
                        "latched result mismatch " + trial + ":" + i);
            }
        }
        boolean invalidLimit = false;
        try { new RecoveryCircuitBreaker(0, 60_000L); }
        catch (IllegalArgumentException expected) { invalidLimit = true; }
        verify(invalidLimit, "bad limit rejected");
        boolean invalidWindow = false;
        try { new RecoveryCircuitBreaker(3, 0); }
        catch (IllegalArgumentException expected) { invalidWindow = true; }
        verify(invalidWindow, "bad window rejected");
        System.out.println("PASS: " + checked + " recovery-policy checks");
    }
}
