#!/usr/bin/env python3
"""Static Android project checks + compilable pure-Java overlay-geometry tests.
This does NOT replace assembling/running an APK on Android.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from xml.etree import ElementTree as ET
import subprocess
import sys
import re

root = Path(__file__).resolve().parents[1]
src = root / 'app/src/main/java/id/wwm/bgoneoverlay'
service = (src / 'MapOverlayService.java').read_text()
browser = (src / 'BrowserController.java').read_text()
geometry = (src / 'OverlayGeometry.java').read_text()
nav = (src / 'NavigationPolicy.java').read_text()
activity = (src / 'MainActivity.java').read_text()
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
gradle = (root / 'app/build.gradle').read_text()
workflow = (root / '.github/workflows/build-apk.yml').read_text()
ns = '{http://schemas.android.com/apk/res/android}'
permissions = {e.get(ns + 'name') for e in manifest.findall('uses-permission')}

checks = {
    'Situs BgOne asli melalui WebView': 'https://bgonegaming.win/wherewindmeets/' in browser,
    'Service overlay berbasis izin resmi Android': 'TYPE_APPLICATION_OVERLAY' in service and 'Settings.canDrawOverlays(this)' in service,
    'Browser dipisahkan dari jendela overlay': 'final class BrowserController' in browser and 'new BrowserController(this' in service,
    'Mode minimal/interaktif/lihat/quick peek': all(s in service for s in ('BUBBLE, INTERACTIVE, VIEW, PEEK','showBubble()', 'showInteractive()', 'showReadOnly()', 'showPeek()')),
    'Panel Mode Lihat noninteraktif': 'FLAG_NOT_TOUCHABLE' in service,
    'Transparansi read-only memakai batas perangkat': 'MAX_SAFE_READ_ONLY_ALPHA = 0.75f' in geometry and 'getMaximumObscuringOpacityForTouch' in service and 'safePassiveOpacity()' in service,
    'Pengendali terpisah tanpa bertumpuk': 'showReadControl' in service and 'readOnly(' in geometry,
    'Quick Peek memakai batas waktu': 'handler.postDelayed(peekTimeout, PEEK_MILLIS)' in service and 'cancelPeek()' in service,
    'Reset fokus/keyboard otomatis': 'exitKeyboard();' in service and 'hideSoftInputFromWindow' in service,
    'Preset posisi dua orientasi': 'land_' in service and 'port_' in service and 'loadProfile()' in service,
    'Cegah geser/resize tidak sengaja': 'private boolean locked' in service and 'toggleLock()' in service,
    'WebView dijeda saat gelembung': 'browser.pause()' in service and 'browser.resume()' in service,
    'Hemat memori saat panel tersembunyi': 'onTrimMemory(int level)' in service and 'discardHidden()' in browser,
    'Recovery WebView renderer tanpa mendaur ulang': 'onRenderProcessGone(' in browser and 'v.destroy()' in browser and 'browser = null' in browser,
    'Pemulihan WebView memasang ulang panel': 'browser.reload();\n            attachBrowser();'.replace('\\n', '\n') in service,
    'Penghenti crash berulang terintegrasi': 'rendererGate.recordFailure' in browser and 'rendererGate.isBlocked()' in browser,
    'Callback progres dilindungi dari WebView lama': 'v == browser && progress < 100' in browser,
    'Popup ditutup di timeout 8 detik': 'main.postDelayed(() -> destroyPopup(popup), 8000)' in browser,
    'Error HTTP/SSL/jaringan diproses': all(x in browser for x in ('onReceivedError', 'onReceivedHttpError', 'handler.cancel()')),
    'WebView JS dan storage situs': 'setJavaScriptEnabled(true)' in browser and 'setDomStorageEnabled(true)' in browser,
    'Tanpa injeksi JS di situs': 'evaluateJavascript' not in browser and 'addJavascriptInterface' not in browser,
    'Tanpa akses game atau capture': all(x not in service+browser for x in ('AccessibilityService','MediaProjection','Runtime.exec','Instrumentation')),
    'Notifikasi punya Stop dan Minimize': 'ACTION_STOP' in service and 'ACTION_HIDE' in service and '.addAction(' in service,
    'Tidak mengekspor service': any(x.get(ns+'name')=='.MapOverlayService' and x.get(ns+'exported')=='false' for x in manifest.find('application').findall('service')),
    'Permission esensial tersedia': {'android.permission.INTERNET','android.permission.SYSTEM_ALERT_WINDOW','android.permission.FOREGROUND_SERVICE_SPECIAL_USE'}.issubset(permissions),
    'Proyek v1.0': 'versionCode 10' in gradle and "versionName '1.0.0'" in gradle,
    'Workflow bangun APK GitHub Actions': 'assembleDebug' in workflow and 'upload-artifact@v4' in workflow,
    'Aktivitas izin notifikasi sebelum memulai overlay': 'requestPermissions(' in activity and 'onRequestPermissionsResult' in activity,
    'Service startup tidak mengulang ketika FGS gagal': 'foregroundReady' in service and '!foregroundReady' in service,
    'URL dibatasi host valid': 'NavigationPolicy.isBgOne' in browser and 'isBgOne(String scheme, String host)' in nav,
    'Hapus token URL sebelum disimpan': 'NavigationPolicy.persistentUrl' in browser and 'getRawPath()' in nav,
    'WebView punya guard callback usang': 'browser != v' in browser and 'loadSequence == id' in browser,
    'Loading watchdog dibatalkan ketika WebView dihancurkan': 'cancelWatchdog()' in browser and 'main.postDelayed(loadingWatchdog' in browser,
    'Akses file/content WebView dinonaktifkan': 'setAllowFileAccess(false)' in browser and 'setAllowContentAccess(false)' in browser,
    'Tidak memiliki izin capture/accessibility': 'android.permission.BIND_ACCESSIBILITY_SERVICE' not in permissions and 'android.permission.CAPTURE_VIDEO_OUTPUT' not in permissions,
}

# Verify no obviously unmatched delimiters outside strings/comments via a simple lexical scan.
def delimiters(text):
    state = 'code'; stack=[]; i=0
    pairs={')':'(',']':'[','}':'{'}
    while i < len(text):
        c=text[i]; nxt=text[i:i+2]
        if state=='code':
            if nxt=='//':state='line';i+=2;continue
            if nxt=='/*':state='block';i+=2;continue
            if c=='"':state='string'
            elif c=="'":state='char'
            elif c in '({[':stack.append(c)
            elif c in ')}]':
                if not stack or stack.pop()!=pairs[c]:return False
        elif state=='line':
            if c=='\n':state='code'
        elif state=='block':
            if nxt=='*/':state='code';i+=2;continue
        elif state in ('string','char'):
            if c=='\\':i+=2;continue
            if c==('"' if state=='string' else "'"):state='code'
        i+=1
    return not stack and state in ('code','line')

checks['Kurung Java seimbang pada 5 source'] = all(delimiters((src/name).read_text()) for name in
        ['MapOverlayService.java','BrowserController.java','OverlayGeometry.java','NavigationPolicy.java','MainActivity.java'])

try:
    with TemporaryDirectory() as temp:
        subprocess.run(['javac', '-encoding','UTF-8','-d', temp, str(src/'OverlayGeometry.java'), str(src/'NavigationPolicy.java'),
            str(root/'tests/OverlayGeometryTest.java'), str(root/'tests/PolicyAndGeometryTest.java'),
            str(src/'RecoveryCircuitBreaker.java'), str(root/'tests/RecoveryCircuitBreakerTest.java')], check=True, capture_output=True, text=True)
        result = subprocess.run(['java', '-ea', '-cp', temp, 'id.wwm.bgoneoverlay.OverlayGeometryTest'],
            check=True, capture_output=True, text=True)
        policy_result = subprocess.run(['java', '-ea', '-cp', temp, 'id.wwm.bgoneoverlay.PolicyAndGeometryTest'],
            check=True, capture_output=True, text=True)
        recovery_result = subprocess.run(['java', '-ea', '-cp', temp, 'id.wwm.bgoneoverlay.RecoveryCircuitBreakerTest'],
            check=True, capture_output=True, text=True)
    checks['Tes Java geometri landscape/portrait'] = 'PASS:' in result.stdout
    checks['24.129 tes Java properti URL, opacity, dan bounds'] = 'PASS: 24129 deterministic checks' in policy_result.stdout
    checks['Tes pemutus loop crash renderer'] = 'PASS:' in recovery_result.stdout
    print(recovery_result.stdout.strip())
except (subprocess.CalledProcessError, OSError) as exc:
    print('GEOMETRY TEST ERROR', str(exc), getattr(exc,'stderr',''))
    checks['Tes Java geometri landscape/portrait'] = False
    checks['24.129 tes Java properti URL, opacity, dan bounds'] = False
    checks['Tes pemutus loop crash renderer'] = False

for title, valid in checks.items():
    print(('PASS' if valid else 'FAIL') + '  ' + title)
print(f'\n{sum(checks.values())}/{len(checks)} pemeriksaan offline lolos')
sys.exit(0 if all(checks.values()) else 1)
