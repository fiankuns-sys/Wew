# QA APK Android — WWM BgOne Overlay v1.0

## Tahap A — Audit build GitHub Actions

Unggah source ke root repo → **Actions** → **Bangun APK Android** → **Run workflow**.

| Nomor | Tes | Lulus jika |
|---|---|---|
| A1 | Source Java offline | 39/39 cek PASS, Java tests selesai |
| A2 | Install SDK/Gradle | Langkah `setup-android` dan `setup-gradle` tidak error |
| A3 | `lintDebug` | Tidak ada error yang membuat build gagal |
| A4 | `assembleDebug` | `app-debug.apk` diunggah sebagai artifact |
| A5 | APK dipasang | Sistem Android menerima APK tanpa error |

## Tahap B — QA di Android

1. **Izin:** overlay dimatikan → startup menampilkan peringatan. Beri izin dan ulangi.
2. **PETA:** mulai overlay, pastikan gelembung bisa dipindah dan diketuk.
3. **WWM:** masuk game landscape, periksa apakah game mengizinkan overlay dan apakah tombol PETA muncul. Bila diblokir, hentikan overlay dan gunakan browser, jangan mengakali proteksi.
4. **Peta BgOne:** periksa gambar dasar, filter, perbesar/perkecil peta, ketuk 10 pin, buka foto, pindah ke area lain.
5. **Interaksi game:** sentuh kontrol WWM di luar panel dan kemudian di bawah Mode Lihat. Jika kontrol tidak aktif, pakai Quick Peek atau Minimize.
6. **Keyboard:** tekan Ketik, gunakan pencarian, kembali ke Main, dan coba keyboard ketika panel diperkecil.
7. **Quick Peek:** tekan tahan PETA; peta harus tampil sementara dan menyusut setelah kira-kira 9 detik.
8. **Orientasi dan posisi:** lakukan rotasi portrait → landscape berulang, cek tombol tetap bisa dijangkau.
9. **Jaringan:** aktifkan nonaktif Wi-Fi/data sementara, pastikan ada status error dan reload setelah tersambung.
10. **Sesi:** minimalkan lalu buka kembali; periksa apakah halaman tetap ada. Jika WebView terbuang karena RAM, hanya URL aman terakhir dapat pulih.
11. **Crash renderer:** uji hanya pada lingkungan pengembangan yang terkendali; setelah beberapa crash berdekatan, pastikan aplikasi tidak mencoba membuka WebView tanpa batas. Tombol Reload digunakan untuk retry manual.
12. **Performa:** main 30 menit dengan panel aktif dan dibuka-tutup; catat FPS yang dirasakan, suhu, penggunaan RAM, serta frekuensi crash.
13. **Exit:** hentikan dari notifikasi dan aplikasi; semua jendela harus hilang.
14. **Konsistensi:** ulangi start/stop setidaknya 10 kali; tidak boleh meninggalkan tombol PETA ganda.

## Cara membuat laporan error

Sertakan: model perangkat, versi Android, versi Android System WebView, screenshot jika relevan, langkah reproduksi, hasil yang diharapkan, hasil nyata, nama workflow/step build yang gagal.

Jika menggunakan ADB:

```bash
adb logcat -v time -s WWMOverlay AndroidRuntime chromium
```

Log bisa memuat data sensitif. Periksa dan hapus token, cookie, email, ID akun, serta alamat pribadi sebelum membagikannya.

## Status

Checklist ini masih **belum dijalankan di perangkat nyata**. Lulus pengujian logika bukan pengganti pengujian Android + WWM.
