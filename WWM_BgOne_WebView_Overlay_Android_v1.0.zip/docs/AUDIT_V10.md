# Audit v1.0 — WWM BgOne Overlay

Tanggal: 11 November 2026. Audit dilakukan atas source v0.9 dan perbaikan v1.0.

## Perbaikan yang benar-benar diubah

| ID | Gejala/risiko v0.9 | Penyebab | Perbaikan kode | Verifikasi |
|---|---|---|---|---|
| F-01 | Panel putih/kosong sesudah renderer hilang dan pengguna mengetuk Reload | `attachBrowser()` terjadi sebelum `browser.reload()` menciptakan instance baru | Balik urutan: `browser.reload(); attachBrowser()`; penanganan gagal di tempat | Inspeksi source (belum diuji di perangkat) |
| F-02 | Siklus crash berulang pada halaman yang sama | Tidak ada circuit breaker | `RecoveryCircuitBreaker` 3 kejadian/60 detik, retry manual | 40.524 asersi Java |
| F-03 | Persentase loading lama menimpa pesan error | Callback Chrome belum cek WebView aktif | `if (v == browser)` sebelum update status | Inspeksi source |
| F-04 | Popup yang masih tertinggal setelah peta utama dilepas | `destroyBrowser()` tidak menutup semua popup | Tutup popup aktif sebelum destroy browser | Inspeksi source |
| F-05 | Jendela salah posisi setelah beberapa rotasi cepat | Pengukuran ulang dilakukan terlalu cepat dan tanpa pembatalan callback usang | `deferredReflow` 120 ms dan batalkan reflow lama; keluarkan fokus keyboard | Inspeksi source (uji ROM diperlukan) |

## Pengujian yang tersedia

- `python3 tests/check_source.py`: **39/39 PASS**.
- Tes Java kebijakan URL, batas opasitas, dan 4.000 variasi geometri: **24.129 asersi PASS**.
- Tes Java `RecoveryCircuitBreaker`: **40.524 pemeriksaan PASS**.
- Pemeriksaan XML/struktur source, Java delimiter, manifest dan jalur workflow: PASS.
- Validasi kompatibilitas AGP versi 8.9.2 dengan Gradle 8.11.1, API 35, dan Java 17 dari dokumentasi Android: cocok **di atas kertas**, belum dikompilasi.

> Pemeriksaan teks/static tidak sama dengan kompilasi bytecode aplikasi. Tes murni Java tidak menjalankan framework Android.

## Risiko tersisa yang belum dapat disebut selesai

- **P0 — Build APK dan Android Lint**: memerlukan Android SDK pada runner GitHub Actions atau mesin build.
- **P0 — Overlay di WWM**: game atau pengaturan Android dapat menolak overlay. Tidak ada cara yang dijamin aman untuk memaksanya tampil.
- **P0 — Sentuhan di balik Mode Lihat**: `FLAG_NOT_TOUCHABLE` + opasitas tidak menjamin pass-through pada semua ROM, apalagi jika ada overlay lain.
- **P1 — Foto, pin, filter, login BgOne**: perlu uji interaksi nyata karena website bisa memperbarui frontend atau memblokir WebView.
- **P1 — Tekanan memori/GPU**: uji WWM dan WebView bersamaan minimal 20–30 menit, pantau proses renderer dan suhu perangkat.
- **P1 — Login, cookie, Google auth, popup, upload/download**: beberapa alur mungkin butuh browser utama. Cookie antar browser tidak otomatis sama.
- **P1 — Keyboard, orientasi, cutout, full-screen Android 16**: bergantung perangkat, UI/UX game, dan implementasi ROM.
- **P2 — Pemulihan posisi peta**: URL terakhir disimpan tanpa query token; zoom/filter dinamis website tidak otomatis dipulihkan ketika renderer dihancurkan.

## Kriteria penerimaan

Rilis hanya dapat diberi status "Siap diuji di WWM" setelah CI `lintDebug assembleDebug` berhasil dan APK berhasil dipasang. Status "Teruji bersama WWM" memerlukan bukti pengujian input/peta/galeri/performa di perangkat. Status "bebas bug" tidak dapat dijamin secara absolut.

## Rujukan Android

- WebView Renderer: https://developer.android.com/develop/ui/views/layout/webapps/handle-termination
- Untrusted touches Android 12: https://developer.android.com/about/versions/12/behavior-changes-all
- Foreground service restrictions Android 15: https://developer.android.com/about/versions/15/behavior-changes-15
- AGP 8.9.2: https://developer.android.com/build/releases/agp-8-9-0-release-notes
