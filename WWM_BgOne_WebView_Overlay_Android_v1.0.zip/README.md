# WWM · BgOne WebView Overlay v1.0

Aplikasi Android pendamping tidak resmi yang menampilkan **https://bgonegaming.win/wherewindmeets/** di sebuah WebView melayang ketika Android dan *Where Winds Meet* mengizinkan. Data pin dan gambar dimuat dari website, **tidak disalin** ke APK. Tidak memodifikasi game, membaca memori, atau mengakali pembatasan overlay.

## Status nyata

- **LULUS:** 39 pemeriksaan offline proyek/struktur, pengujian geometri dan navigasi Java (24.129 asersi), serta **40.524 pemeriksaan** logika pembatas crash.
- **BELUM DIUJI:** `assembleDebug`/Android Lint pada SDK Android; pemasangan APK; pemuatan BgOne secara nyata di perangkat; perilaku overlay di atas WWM; konsumsi memori/GPU serta stabilitas 30 menit.
- **Belum ada APK teruji dalam paket ini.** Hanya source Android dan workflow GitHub Actions untuk melakukan kompilasi.

## Fungsi dari v0.9 yang dipertahankan

- Tombol PETA melayang, ketuk untuk panel interaktif, tahan untuk Quick Peek 9 detik.
- Mode Interaktif; Mode Lihat noninteraktif (dibatasi transparansinya), pengendali ATUR terpisah; ukuran/posisi/transparansi, kunci posisi.
- Pencarian dengan tombol Ketik/Main; tombol reload, Home, Back, Forward, membuka situs di browser utama.
- Pemulihan jaringan, error SSL dan HTTP, serta renderer berhenti.
- Simpan tata letak khusus landscape/portrait; foreground service dengan tombol Perkecil/Hentikan melalui notifikasi.
- JavaScript, DOM storage dan cookie situs; akses file/content WebView tidak diizinkan.

## Pembaruan v1.0

1. **Bug panel kosong setelah tombol reload:** jika renderer WebView hilang, urutan recovery kini *buat/muat WebView baru → pasang ke kontainer*.
2. **Pembatas crash:** setelah tiga renderer failure dalam 60 detik, percobaan recovery **otomatis** diblokir. Status menampilkan pilihan retry manual atau browser. Ketuk Reload untuk mencoba lagi secara sadar.
3. **Cegah callback lama menimpa status baru:** update persentase loading dan download hanya diterima dari WebView yang masih aktif; state loading ditandai gagal saat renderer mati.
4. **Bersihkan popup:** popup WebView yang masih hidup ditutup saat browser utama dihancurkan sehingga tidak meninggalkan sesi yang sudah tidak relevan.
5. **Rotasi cepat:** reflow dijadwalkan ulang setelah metrik orientasi biasanya selesai diperbarui; keyboard dikembalikan ke mode nonfokus saat layar berputar.
6. **Tes baru:** `RecoveryCircuitBreakerTest.java` memverifikasi batas waktu, reset, rollback waktu, serta 100 × 200 skenario acak.

Tidak ada klaim bahwa web BgOne mengizinkan semua fitur dalam WebView. Login pihak ketiga, popup, captcha dan download bisa memerlukan browser eksternal. Android 12+ dapat menolak sentuhan di belakang overlay noninteraktif; apabila ini terjadi, gunakan Quick Peek atau kecilkan peta.

## Build APK lewat GitHub Actions

1. Ekstrak ZIP, unggah semua isinya ke **root** repo GitHub sendiri termasuk `.github/`, `app/`, `tests/`, `settings.gradle`.
2. Buka tab **Actions** → **Bangun APK Android** → **Run workflow**.
3. Workflow menjalankan `python3 tests/check_source.py`, memasang Android SDK API 35, menjalankan `gradle --no-daemon lintDebug assembleDebug`, dan mengunggah hasil APK.
4. Hanya jika build berhasil, unduh artifact `WWM-BgOne-Overlay-v1.0-debug`, ekstrak, dan pasang `app-debug.apk` di Android.
5. Beri izin **Tampil di atas aplikasi lain**, mulai overlay dari aktivitas utama, lalu coba bersama WWM.
6. Jika muncul error, ambil log workflow dan ikuti `docs/QA_ANDROID.md`. Jangan menganggap APK lulus hanya karena tes offline lulus.

**Versi build teruji kecocokannya di dokumentasi Android**: AGP 8.9.2 + Gradle 8.11.1 + JDK 17 + compileSdk 35. Tetapi kombinasinya **belum dibangun di lingkungan kerja ini** karena tidak ada Android SDK/Gradle maupun akses unduhan dependensi.

## Batas keamanan dan privasi

- WebView mengunjungi alamat BgOne dengan HTTPS; website adalah pihak ketiga yang mengelola login, aktivitas dan cookie.
- Jika overlay ditolak oleh game, jangan mengubah pengamanan game. Buka situs di browser utama.
- Aplikasi menggunakan izin overlay dan foreground service; tidak memakai Accessibility, root, screen capture, atau input injection.
- Proyek bukan produk resmi BgOne atau penerbit WWM. Tidak ada afiliasi.
- Jika menerbitkan di toko aplikasi, tinjau deklarasi tipe `specialUse`, izin foreground service, dan kebijakan toko.

Lihat `docs/AUDIT_V10.md` dan `docs/QA_ANDROID.md` untuk bukti dan pengujian penerimaan.
